from telegram import InlineKeyboardButton, InlineKeyboardMarkup

SHOP_ITEMS = {
    'qurol': {
        'name': '🔫 Qo\'shimcha qurol',
        'description': 'Qo\'shimcha o\'q — bir kechada 2 marta o\'q uzatish',
        'price': 30,
        'currency': 'coins',
    },
    'bronejjilet': {
        'name': '🛡 Bronjejilet',
        'description': 'Bir marta o\'limdan himoya qiladi',
        'price': 50,
        'currency': 'coins',
    },
    'dori': {
        'name': '💊 Qo\'shimcha dori',
        'description': 'Doktor bir kechada 2 marta davolay oladi',
        'price': 25,
        'currency': 'coins',
    },
    'ko_zoynak': {
        'name': '🔭 Ko\'zoynak',
        'description': 'Detektiv 2 kishini bir kechada tekshira oladi',
        'price': 40,
        'currency': 'coins',
    },
    'bomba': {
        'name': '💣 Portlovchi',
        'description': 'Manyak uchun kuchliroq portlovchi — 2 kishini o\'ldiradi',
        'price': 60,
        'currency': 'coins',
    },
    'olmos_qurol': {
        'name': '💎 Olmos qurol',
        'description': 'Himoyani yorib o\'tadi — doktor ham qutqara olmaydi',
        'price': 5,
        'currency': 'diamonds',
    },
    'olmos_zirhli': {
        'name': '💎 Olmos zirh',
        'description': '3 marta o\'limdan himoya qiladi',
        'price': 8,
        'currency': 'diamonds',
    },
    'olmos_ko_z': {
        'name': '💎 Sehrli ko\'z',
        'description': 'Rolni to\'liq ko\'rsatadi (Detektiv uchun)',
        'price': 10,
        'currency': 'diamonds',
    },
}

class Shop:
    def get_keyboard(self):
        keyboard = []
        row = []
        for item_id, item in SHOP_ITEMS.items():
            currency_icon = "💎" if item['currency'] == 'diamonds' else "🪙"
            btn = InlineKeyboardButton(
                f"{item['name']} — {item['price']}{currency_icon}",
                callback_data=f"buy_{item_id}"
            )
            keyboard.append([btn])
        return InlineKeyboardMarkup(keyboard)

    def get_item(self, item_id):
        return SHOP_ITEMS.get(item_id)
