# 🎭 Mafiya Samurai Bot

## O'rnatish

### 1. GitHub ga yuklash
1. GitHub da yangi repository oching
2. Barcha fayllarni yuklang

### 2. Railway ga deploy
1. railway.app ga kiring
2. "New Project" → "GitHub Repository" tanlang
3. Bu reponi tanlang
4. "Variables" bo'limiga o'ting
5. `BOT_TOKEN` ni qo'shing (BotFather dan olgan token)
6. Deploy tugmasini bosing ✅

## Rollar
- 👑 Don — Mafiya boshlig'i
- 🌙 Mafia — Mafiya a'zosi
- 💣 Manyak — Portlovchi qo'yadi
- 💋 Fohisha — Qobiliyatni bloklaydi
- ☀️ Tinch — Oddiy fuqaro
- 🔍 Detektiv — Rol tekshiradi
- 💊 Doktor — Davolaydi
- 🎯 Snayper — Himoya qiladi

## Buyruqlar
- /yangioyun — Yangi o'yin
- /qoshilish — O'yinga qo'shilish
- /boshlash — O'yinni boshlash
- /tunguvoh — Tunni tugatish
- /ovoz @username — Ovoz berish
- /otish @username — O'q uzatish
- /davolash @username — Davolash
- /tekshirish @username — Tekshirish
- /himoya @username — Himoya
- /sevish @username — Bloklash
- /portlatish @username — Portlatish
- /dokon — Do'kon
- /balans — Balans
- /transfer @username miqdor — Pul o'tkazish
