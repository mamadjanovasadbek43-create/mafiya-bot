import logging
import os
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import (
    Application, CommandHandler, CallbackQueryHandler,
    MessageHandler, filters, ContextTypes
)
from database import Database
from game import Game
from shop import Shop

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

TOKEN = os.environ.get("BOT_TOKEN")
db = Database()
games = {}  # chat_id -> Game

# ========================
# ASOSIY BUYRUQLAR
# ========================

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    db.add_user(user.id, user.first_name, user.username)
    await update.message.reply_text(
        f"🎭 Salom, {user.first_name}!\n\n"
        "🗡 *Mafiya Samurai* o'yiniga xush kelibsiz!\n\n"
        "📋 Buyruqlar:\n"
        "/yangioyun — Yangi o'yin boshlash\n"
        "/qoshilish — O'yinga qo'shilish\n"
        "/dokon — Do'kon\n"
        "/balans — Balans ko'rish\n"
        "/yordam — Yordam",
        parse_mode="Markdown"
    )

async def yordam(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text(
        "🎭 *MAFIYA SAMURAI — YORDAM*\n\n"
        "🎮 *O'yin buyruqlari:*\n"
        "/yangioyun — Yangi o'yin yaratish\n"
        "/qoshilish — O'yinga qo'shilish\n"
        "/boshlash — O'yinni boshlash (admin)\n"
        "/rolim — Rolimni ko'rish\n"
        "/ovoz @username — Ovoz berish\n"
        "/otish @username — O'q uzatish\n"
        "/davolash @username — Davolash (Doktor)\n"
        "/tekshirish @username — Tekshirish (Detektiv)\n"
        "/himoya @username — Himoya (Snayper)\n"
        "/sevish @username — Sevish (Fohisha)\n"
        "/portlatish @username — Portlatish (Manyak)\n\n"
        "🛒 *Do'kon:*\n"
        "/dokon — Do'kon ochish\n"
        "/balans — Balans ko'rish\n"
        "/transfer @username miqdor — Pul o'tkazish\n\n"
        "👑 *Rollar:*\n"
        "☀️ Tinch tomonlar: Tinch, Detektiv, Doktor, Snayper\n"
        "🌙 Mafia tomoni: Don, Mafia, Manyak, Fohisha\n",
        parse_mode="Markdown"
    )

async def balans(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    data = db.get_user(user.id)
    if not data:
        db.add_user(user.id, user.first_name, user.username)
        data = db.get_user(user.id)
    await update.message.reply_text(
        f"💰 *{user.first_name} balansi:*\n\n"
        f"💎 Olmos: {data['diamonds']}\n"
        f"🪙 Tangalar: {data['coins']}\n",
        parse_mode="Markdown"
    )

async def transfer(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    args = context.args
    if len(args) < 2:
        await update.message.reply_text("❌ Foydalanish: /transfer @username miqdor")
        return
    username = args[0].replace("@", "")
    try:
        amount = int(args[1])
    except ValueError:
        await update.message.reply_text("❌ Miqdor son bo'lishi kerak!")
        return
    if amount <= 0:
        await update.message.reply_text("❌ Miqdor musbat bo'lishi kerak!")
        return
    sender = db.get_user(user.id)
    receiver = db.get_user_by_username(username)
    if not receiver:
        await update.message.reply_text("❌ Foydalanuvchi topilmadi!")
        return
    if sender['coins'] < amount:
        await update.message.reply_text("❌ Tangalar yetarli emas!")
        return
    db.transfer_coins(user.id, receiver['user_id'], amount)
    await update.message.reply_text(
        f"✅ {amount} 🪙 tanga @{username} ga o'tkazildi!"
    )

# ========================
# O'YIN BUYRUQLARI
# ========================

async def yangi_oyun(update: Update, context: ContextTypes.DEFAULT_TYPE):
    chat_id = update.effective_chat.id
    user = update.effective_user
    if chat_id > 0:
        await update.message.reply_text("❌ Bu buyruq faqat guruhlarda ishlaydi!")
        return
    if chat_id in games and games[chat_id].status == "waiting":
        await update.message.reply_text("⚠️ Allaqachon o'yin kutilmoqda! /qoshilish bilan qo'shiling.")
        return
    db.add_user(user.id, user.first_name, user.username)
    games[chat_id] = Game(chat_id, user.id)
    games[chat_id].add_player(user.id, user.first_name, user.username)
    keyboard = [[InlineKeyboardButton("🎮 Qo'shilish", callback_data="join_game")]]
    reply_markup = InlineKeyboardMarkup(keyboard)
    await update.message.reply_text(
        f"🎭 *Yangi o'yin boshlandi!*\n\n"
        f"👑 Yaratuvchi: {user.first_name}\n"
        f"👥 O'yinchilar: 1\n\n"
        f"Qo'shilish uchun tugmani bosing yoki /qoshilish yozing!\n"
        f"Kamida 4 ta o'yinchi kerak.\n"
        f"Boshlash uchun: /boshlash",
        parse_mode="Markdown",
        reply_markup=reply_markup
    )

async def qoshilish(update: Update, context: ContextTypes.DEFAULT_TYPE):
    chat_id = update.effective_chat.id
    user = update.effective_user
    if chat_id not in games:
        await update.message.reply_text("❌ Hozir o'yin yo'q. /yangioyun bilan boshlang!")
        return
    game = games[chat_id]
    if game.status != "waiting":
        await update.message.reply_text("❌ O'yin allaqachon boshlangan!")
        return
    db.add_user(user.id, user.first_name, user.username)
    result = game.add_player(user.id, user.first_name, user.username)
    if result == "already":
        await update.message.reply_text("⚠️ Siz allaqachon o'yindasiz!")
        return
    await update.message.reply_text(
        f"✅ *{user.first_name}* o'yinga qo'shildi!\n"
        f"👥 Jami o'yinchilar: {len(game.players)}",
        parse_mode="Markdown"
    )

async def join_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    chat_id = update.effective_chat.id
    user = query.from_user
    if chat_id not in games:
        await query.answer("❌ O'yin topilmadi!", show_alert=True)
        return
    game = games[chat_id]
    if game.status != "waiting":
        await query.answer("❌ O'yin allaqachon boshlangan!", show_alert=True)
        return
    db.add_user(user.id, user.first_name, user.username)
    result = game.add_player(user.id, user.first_name, user.username)
    if result == "already":
        await query.answer("⚠️ Siz allaqachon o'yindasiz!", show_alert=True)
        return
    await context.bot.send_message(
        chat_id,
        f"✅ *{user.first_name}* o'yinga qo'shildi!\n"
        f"👥 Jami o'yinchilar: {len(game.players)}",
        parse_mode="Markdown"
    )

async def boshlash(update: Update, context: ContextTypes.DEFAULT_TYPE):
    chat_id = update.effective_chat.id
    user = update.effective_user
    if chat_id not in games:
        await update.message.reply_text("❌ Hozir o'yin yo'q!")
        return
    game = games[chat_id]
    if game.creator_id != user.id:
        await update.message.reply_text("❌ Faqat o'yin yaratuvchisi boshlashi mumkin!")
        return
    if len(game.players) < 4:
        await update.message.reply_text(f"❌ Kamida 4 ta o'yinchi kerak! Hozir: {len(game.players)}")
        return
    game.assign_roles()
    game.status = "night"
    players_list = "\n".join([f"• {p['name']}" for p in game.players.values()])
    await update.message.reply_text(
        f"🎭 *O'YIN BOSHLANDI!*\n\n"
        f"👥 O'yinchilar:\n{players_list}\n\n"
        f"🌙 *1-kecha boshlanmoqda...*\n"
        f"Har bir o'yinchi shaxsiy xabarda o'z rolini oladi!",
        parse_mode="Markdown"
    )
    for player_id, player in game.players.items():
        role_info = game.get_role_info(player['role'])
        try:
            await context.bot.send_message(
                player_id,
                f"🎭 *Sizning rolingiz: {role_info['name']}*\n\n"
                f"{role_info['description']}\n\n"
                f"{role_info['ability']}",
                parse_mode="Markdown"
            )
        except Exception:
            pass
    await start_night(update, context, chat_id)

async def start_night(update, context, chat_id):
    game = games[chat_id]
    game.night += 1
    game.night_actions = {}
    alive_players = game.get_alive_players()
    players_list = "\n".join([f"• {p['name']}" for p in alive_players.values()])
    await context.bot.send_message(
        chat_id,
        f"🌙 *{game.night}-KECHA*\n\n"
        f"😴 Shahar uxlayapti...\n\n"
        f"👥 Tirik o'yinchilar:\n{players_list}\n\n"
        f"🔫 Mafia, Don — /otish @username\n"
        f"🔍 Detektiv — /tekshirish @username\n"
        f"💊 Doktor — /davolash @username\n"
        f"🎯 Snayper — /himoya @username\n"
        f"💋 Fohisha — /sevish @username\n"
        f"💣 Manyak — /portlatish @username",
        parse_mode="Markdown"
    )

async def rolim(update: Update, context: ContextTypes.DEFAULT_TYPE):
    chat_id = update.effective_chat.id
    user = update.effective_user
    if chat_id not in games:
        await update.message.reply_text("❌ Hozir o'yin yo'q!")
        return
    game = games[chat_id]
    if user.id not in game.players:
        await update.message.reply_text("❌ Siz bu o'yinda emassiz!")
        return
    player = game.players[user.id]
    role_info = game.get_role_info(player['role'])
    try:
        await context.bot.send_message(
            user.id,
            f"🎭 *Sizning rolingiz: {role_info['name']}*\n\n"
            f"{role_info['description']}\n\n"
            f"{role_info['ability']}",
            parse_mode="Markdown"
        )
        await update.message.reply_text("✅ Rol ma'lumoti shaxsiy xabarga yuborildi!")
    except Exception:
        await update.message.reply_text("❌ Shaxsiy xabar yubora olmadim. Avval botga /start yozing!")

async def ovoz(update: Update, context: ContextTypes.DEFAULT_TYPE):
    chat_id = update.effective_chat.id
    user = update.effective_user
    args = context.args
    if chat_id not in games:
        await update.message.reply_text("❌ Hozir o'yin yo'q!")
        return
    game = games[chat_id]
    if game.status != "day":
        await update.message.reply_text("❌ Ovoz berish faqat kunduz bo'ladi!")
        return
    if not args:
        await update.message.reply_text("❌ Foydalanish: /ovoz @username")
        return
    if user.id not in game.players or not game.players[user.id]['alive']:
        await update.message.reply_text("❌ Siz o'yinda emassiz yoki o'ldirilgansiz!")
        return
    target_username = args[0].replace("@", "")
    target = game.get_player_by_username(target_username)
    if not target:
        await update.message.reply_text("❌ Bunday o'yinchi topilmadi!")
        return
    if not target['alive']:
        await update.message.reply_text("❌ Bu o'yinchi allaqachon o'lgan!")
        return
    if target['id'] == user.id:
        await update.message.reply_text("❌ O'zingizga ovoz bera olmaysiz!")
        return
    game.add_vote(user.id, target['id'])
    await update.message.reply_text(
        f"🗳 *{user.first_name}* → *{target['name']}* ga ovoz berdi!",
        parse_mode="Markdown"
    )
    if game.check_voting_complete():
        await end_voting(update, context, chat_id)

async def end_voting(update, context, chat_id):
    game = games[chat_id]
    result = game.get_voting_result()
    if result:
        player = game.players[result]
        game.eliminate_player(result)
        role_info = game.get_role_info(player['role'])
        await context.bot.send_message(
            chat_id,
            f"⚖️ *OVOZ BERISH NATIJASI*\n\n"
            f"😵 *{player['name']}* o'yindan chiqarildi!\n"
            f"🎭 Roli: {role_info['name']}\n\n"
            f"🌙 Kecha boshlanmoqda...",
            parse_mode="Markdown"
        )
    else:
        await context.bot.send_message(
            chat_id,
            "🤝 *Ovozlar teng* — hech kim chiqarilmadi!\n\n🌙 Kecha boshlanmoqda...",
            parse_mode="Markdown"
        )
    winner = game.check_winner()
    if winner:
        await end_game(context, chat_id, winner)
    else:
        game.status = "night"
        await start_night(update, context, chat_id)

async def otish(update: Update, context: ContextTypes.DEFAULT_TYPE):
    chat_id = update.effective_chat.id
    user = update.effective_user
    args = context.args
    if chat_id not in games:
        return
    game = games[chat_id]
    if game.status != "night":
        await update.message.reply_text("❌ O'q uzatish faqat kechasi bo'ladi!")
        return
    if user.id not in game.players:
        return
    player = game.players[user.id]
    if not player['alive']:
        return
    if player['role'] not in ['don', 'mafia', 'snayper']:
        await update.message.reply_text("❌ Sizning rolingiz o'q uza olmaydi!")
        return
    if not args:
        await update.message.reply_text("❌ Foydalanish: /otish @username")
        return
    target_username = args[0].replace("@", "")
    target = game.get_player_by_username(target_username)
    if not target or not target['alive']:
        await update.message.reply_text("❌ Bunday tirik o'yinchi topilmadi!")
        return
    game.add_night_action(user.id, 'shoot', target['id'])
    await update.message.reply_text(f"🔫 Nishon belgilandi! ({target['name']})")

async def davolash(update: Update, context: ContextTypes.DEFAULT_TYPE):
    chat_id = update.effective_chat.id
    user = update.effective_user
    args = context.args
    if chat_id not in games:
        return
    game = games[chat_id]
    if game.status != "night":
        await update.message.reply_text("❌ Davolash faqat kechasi bo'ladi!")
        return
    if user.id not in game.players or game.players[user.id]['role'] != 'doktor':
        await update.message.reply_text("❌ Bu buyruq faqat Doktor uchun!")
        return
    if not args:
        await update.message.reply_text("❌ Foydalanish: /davolash @username")
        return
    target_username = args[0].replace("@", "")
    target = game.get_player_by_username(target_username)
    if not target or not target['alive']:
        await update.message.reply_text("❌ Bunday tirik o'yinchi topilmadi!")
        return
    game.add_night_action(user.id, 'heal', target['id'])
    await update.message.reply_text(f"💊 Davolash belgilandi! ({target['name']})")

async def tekshirish(update: Update, context: ContextTypes.DEFAULT_TYPE):
    chat_id = update.effective_chat.id
    user = update.effective_user
    args = context.args
    if chat_id not in games:
        return
    game = games[chat_id]
    if game.status != "night":
        await update.message.reply_text("❌ Tekshirish faqat kechasi bo'ladi!")
        return
    if user.id not in game.players or game.players[user.id]['role'] != 'detektiv':
        await update.message.reply_text("❌ Bu buyruq faqat Detektiv uchun!")
        return
    if not args:
        await update.message.reply_text("❌ Foydalanish: /tekshirish @username")
        return
    target_username = args[0].replace("@", "")
    target = game.get_player_by_username(target_username)
    if not target or not target['alive']:
        await update.message.reply_text("❌ Bunday tirik o'yinchi topilmadi!")
        return
    game.add_night_action(user.id, 'check', target['id'])
    side = "🌙 MAFIA" if target['role'] in ['don', 'mafia', 'manyak', 'fohisha'] else "☀️ TINCH"
    try:
        await context.bot.send_message(
            user.id,
            f"🔍 *Tekshirish natijasi:*\n\n"
            f"👤 {target['name']} — {side}",
            parse_mode="Markdown"
        )
    except Exception:
        pass
    await update.message.reply_text("🔍 Tekshirish bajarildi! Natija shaxsiy xabarga yuborildi.")

async def himoya(update: Update, context: ContextTypes.DEFAULT_TYPE):
    chat_id = update.effective_chat.id
    user = update.effective_user
    args = context.args
    if chat_id not in games:
        return
    game = games[chat_id]
    if game.status != "night":
        await update.message.reply_text("❌ Himoya faqat kechasi bo'ladi!")
        return
    if user.id not in game.players or game.players[user.id]['role'] != 'snayper':
        await update.message.reply_text("❌ Bu buyruq faqat Snayper uchun!")
        return
    if not args:
        await update.message.reply_text("❌ Foydalanish: /himoya @username")
        return
    target_username = args[0].replace("@", "")
    target = game.get_player_by_username(target_username)
    if not target or not target['alive']:
        await update.message.reply_text("❌ Bunday tirik o'yinchi topilmadi!")
        return
    game.add_night_action(user.id, 'protect', target['id'])
    await update.message.reply_text(f"🎯 Himoya belgilandi! ({target['name']})")

async def sevish(update: Update, context: ContextTypes.DEFAULT_TYPE):
    chat_id = update.effective_chat.id
    user = update.effective_user
    args = context.args
    if chat_id not in games:
        return
    game = games[chat_id]
    if game.status != "night":
        await update.message.reply_text("❌ Bu amal faqat kechasi bo'ladi!")
        return
    if user.id not in game.players or game.players[user.id]['role'] != 'fohisha':
        await update.message.reply_text("❌ Bu buyruq faqat Fohisha uchun!")
        return
    if not args:
        await update.message.reply_text("❌ Foydalanish: /sevish @username")
        return
    target_username = args[0].replace("@", "")
    target = game.get_player_by_username(target_username)
    if not target or not target['alive']:
        await update.message.reply_text("❌ Bunday tirik o'yinchi topilmadi!")
        return
    game.add_night_action(user.id, 'seduce', target['id'])
    await update.message.reply_text(f"💋 Nishon belgilandi! ({target['name']})")

async def portlatish(update: Update, context: ContextTypes.DEFAULT_TYPE):
    chat_id = update.effective_chat.id
    user = update.effective_user
    args = context.args
    if chat_id not in games:
        return
    game = games[chat_id]
    if game.status != "night":
        await update.message.reply_text("❌ Bu amal faqat kechasi bo'ladi!")
        return
    if user.id not in game.players or game.players[user.id]['role'] != 'manyak':
        await update.message.reply_text("❌ Bu buyruq faqat Manyak uchun!")
        return
    if not args:
        await update.message.reply_text("❌ Foydalanish: /portlatish @username")
        return
    target_username = args[0].replace("@", "")
    target = game.get_player_by_username(target_username)
    if not target or not target['alive']:
        await update.message.reply_text("❌ Bunday tirik o'yinchi topilmadi!")
        return
    game.add_night_action(user.id, 'bomb', target['id'])
    await update.message.reply_text(f"💣 Nishon belgilandi! ({target['name']})")

async def tun_tugadi(update: Update, context: ContextTypes.DEFAULT_TYPE):
    chat_id = update.effective_chat.id
    user = update.effective_user
    if chat_id not in games:
        return
    game = games[chat_id]
    if game.status != "night":
        await update.message.reply_text("❌ Hozir kecha emas!")
        return
    if game.creator_id != user.id:
        await update.message.reply_text("❌ Faqat o'yin yaratuvchisi tunni tugatishi mumkin!")
        return
    results = game.process_night_actions()
    result_text = f"🌅 *{game.night}-KECHA YAKUNLANDI*\n\n"
    if results['killed']:
        for killed_id in results['killed']:
            if killed_id in game.players:
                p = game.players[killed_id]
                role_info = game.get_role_info(p['role'])
                result_text += f"💀 *{p['name']}* o'ldirildi! (Rol: {role_info['name']})\n"
    else:
        result_text += "😮 Bu kecha hech kim o'lmadi!\n"
    if results.get('saved'):
        result_text += f"💊 Doktor kimnidir qutqardi!\n"
    winner = game.check_winner()
    if winner:
        await context.bot.send_message(chat_id, result_text, parse_mode="Markdown")
        await end_game(context, chat_id, winner)
        return
    game.status = "day"
    game.votes = {}
    alive_players = game.get_alive_players()
    players_list = "\n".join([f"• {p['name']}" for p in alive_players.values()])
    result_text += f"\n☀️ *KUNDUZ BOSHLANDI!*\n\n"
    result_text += f"👥 Tirik o'yinchilar:\n{players_list}\n\n"
    result_text += "🗳 Ovoz berish: /ovoz @username\n"
    result_text += "Tunni tugatish: /tunguvoh"
    await context.bot.send_message(chat_id, result_text, parse_mode="Markdown")

async def end_game(context, chat_id, winner):
    game = games[chat_id]
    if winner == "mafia":
        msg = "🌙 *MAFIA G'ALABA QILDI!*\n\n"
        msg += "Barcha tinchlar yo'q qilindi. Mafia shaharga hukmronlik qildi!\n\n"
        mafia_players = [p for p in game.players.values() if p['role'] in ['don', 'mafia', 'manyak', 'fohisha']]
        msg += "👥 Mafia a'zolari:\n"
        for p in mafia_players:
            msg += f"• {p['name']} ({game.get_role_info(p['role'])['name']})\n"
    else:
        msg = "☀️ *TINCHLAR G'ALABA QILDI!*\n\n"
        msg += "Mafia yo'q qilindi. Shahar xavfsiz!\n\n"
        peace_players = [p for p in game.players.values() if p['role'] in ['tinch', 'detektiv', 'doktor', 'snayper']]
        msg += "👥 Tinchlar:\n"
        for p in peace_players:
            msg += f"• {p['name']} ({game.get_role_info(p['role'])['name']})\n"
    await context.bot.send_message(chat_id, msg, parse_mode="Markdown")
    for player_id in game.players:
        if winner == "mafia" and game.players[player_id]['role'] in ['don', 'mafia', 'manyak', 'fohisha']:
            db.add_reward(player_id, diamonds=10, coins=50)
        elif winner == "peace" and game.players[player_id]['role'] in ['tinch', 'detektiv', 'doktor', 'snayper']:
            db.add_reward(player_id, diamonds=10, coins=50)
        else:
            db.add_reward(player_id, diamonds=2, coins=10)
    await context.bot.send_message(
        chat_id,
        "🏆 G'oliblar mukofot oldi!\n💎 +10 Olmos, 🪙 +50 Tanga\n\nYangi o'yin: /yangioyun",
        parse_mode="Markdown"
    )
    del games[chat_id]

async def dokon(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    data = db.get_user(user.id)
    if not data:
        db.add_user(user.id, user.first_name, user.username)
        data = db.get_user(user.id)
    shop = Shop()
    keyboard = shop.get_keyboard()
    await update.message.reply_text(
        f"🛒 *DO'KON*\n\n"
        f"💎 Olmoslaringiz: {data['diamonds']}\n"
        f"🪙 Tangalaringiz: {data['coins']}\n\n"
        f"Mahsulot tanlang:",
        parse_mode="Markdown",
        reply_markup=keyboard
    )

async def shop_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    user = query.from_user
    data = query.data
    if not data.startswith("buy_"):
        return
    item_id = data.replace("buy_", "")
    shop = Shop()
    item = shop.get_item(item_id)
    if not item:
        await query.answer("❌ Mahsulot topilmadi!", show_alert=True)
        return
    user_data = db.get_user(user.id)
    currency = item['currency']
    price = item['price']
    if currency == 'diamonds' and user_data['diamonds'] < price:
        await query.answer(f"❌ Olmos yetarli emas! Kerak: {price}💎", show_alert=True)
        return
    if currency == 'coins' and user_data['coins'] < price:
        await query.answer(f"❌ Tanga yetarli emas! Kerak: {price}🪙", show_alert=True)
        return
    db.buy_item(user.id, item_id, currency, price)
    db.add_inventory(user.id, item_id, item['name'])
    await query.answer(f"✅ {item['name']} sotib olindi!", show_alert=True)
    user_data = db.get_user(user.id)
    shop_obj = Shop()
    keyboard = shop_obj.get_keyboard()
    await query.edit_message_text(
        f"🛒 *DO'KON*\n\n"
        f"💎 Olmoslaringiz: {user_data['diamonds']}\n"
        f"🪙 Tangalaringiz: {user_data['coins']}\n\n"
        f"Mahsulot tanlang:",
        parse_mode="Markdown",
        reply_markup=keyboard
    )

def main():
    app = Application.builder().token(TOKEN).build()
    app.add_handler(CommandHandler("start", start))
    app.add_handler(CommandHandler("yordam", yordam))
    app.add_handler(CommandHandler("balans", balans))
    app.add_handler(CommandHandler("transfer", transfer))
    app.add_handler(CommandHandler("yangioyun", yangi_oyun))
    app.add_handler(CommandHandler("qoshilish", qoshilish))
    app.add_handler(CommandHandler("boshlash", boshlash))
    app.add_handler(CommandHandler("rolim", rolim))
    app.add_handler(CommandHandler("ovoz", ovoz))
    app.add_handler(CommandHandler("otish", otish))
    app.add_handler(CommandHandler("davolash", davolash))
    app.add_handler(CommandHandler("tekshirish", tekshirish))
    app.add_handler(CommandHandler("himoya", himoya))
    app.add_handler(CommandHandler("sevish", sevish))
    app.add_handler(CommandHandler("portlatish", portlatish))
    app.add_handler(CommandHandler("tunguvoh", tun_tugadi))
    app.add_handler(CommandHandler("dokon", dokon))
    app.add_handler(CallbackQueryHandler(join_callback, pattern="^join_game$"))
    app.add_handler(CallbackQueryHandler(shop_callback, pattern="^buy_"))
    print("🤖 Mafiya Samurai Bot ishga tushdi!")
    app.run_polling()

if __name__ == "__main__":
    main()
